public interface Stack {
    abstract int length();
    abstract Object pop();
    abstract Boolean push(Object obj);
}