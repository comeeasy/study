package app;

import lib.a;

public class m extends a {
    public int sum(int x, int y) {return x+y;}
    public static void main(String[] args) {
        a _a = new a();

        System.out.println(_a.sum(2, 3));
    }
}
