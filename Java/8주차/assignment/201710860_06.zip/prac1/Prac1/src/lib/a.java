package lib;

import lib.a;

public class a {
    public int sum(int x, int y) {return x+y;};
}
